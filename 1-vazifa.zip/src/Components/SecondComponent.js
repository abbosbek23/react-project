import React,{useState,useEffect} from 'react';
import axios from "axios";
function SecondComponent() {

    const [tasks,setTasks] = useState([])

    useEffect(()=>{
        axios({
            url:'https://jsonplaceholder.typicode.com/todos',
            method:'get'
        }).then((response)=>{
            setTasks(response.data)
        })
    },[])


    return (
        <div>
            <table className={'table table-bordered mt-2'}>
            <thead>
            <tr>
                <th>N</th>
                <th>Title</th>
            </tr>
            </thead>
            <tbody>
            {
                tasks.map((item)=><tr key={item.id}>
                    <td>{item.id}</td>
                    <td>{item.title}</td>
                </tr>)
            }
            </tbody>
        </table>
        </div>
    );
}

export default SecondComponent;