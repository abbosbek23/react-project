import {Link} from 'react-router-dom'

function Home(){
    return(
        <div className={'container'}>
            <div className="row">
                <div className="col-md-6 mt-3">
                    <Link to={'/home/first'}><button className={'btn btn-primary mx-2'}>Posts</button></Link>
                    <Link to={'/home/second'}><button className={'btn btn-primary'}>Tasks</button></Link>
                    <Link to={'/home/third'}><button className={'btn btn-primary mx-2'}>Users</button></Link>
                </div>
            </div>
        </div>
    )
}

export default Home