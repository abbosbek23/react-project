import {useState,useEffect} from 'react';
import axios from "axios";
function FirstComponent() {

    const [data,setData] = useState([])
    useEffect(()=>{
        axios({
            url:'https://jsonplaceholder.typicode.com/posts',
            method:'get'
        }).then((response)=>{
            setData(response.data)
        })
    },[])


    return (
        <div>
         <table className={'table table-bordered mt-2'}>
             <thead>
             <tr>
                 <th>N</th>
                 <th>Title</th>
             </tr>
             </thead>
             <tbody>
             {
                 data.map((item)=><tr>
                     <td>{item.id}</td>
                     <td>{item.title}</td>
                 </tr>)
             }
             </tbody>
         </table>

        </div>
    );
}

export default FirstComponent;