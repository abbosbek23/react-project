import React,{useState,useEffect} from 'react';
import axios from "axios";
function ThirdComponent(props) {

    const [users,setUsers] = useState([])

    useEffect(()=>{
        axios({
            url:'https://jsonplaceholder.typicode.com/users',
            method:'get'
        }).then((response)=>{
            setUsers(response.data)
        })
    },[])

    return (
        <div>
            <table className={'table table-bordered mt-2'}>
                <thead>
                <tr>
                    <th>N</th>
                    <th>Name</th>
                    <th>UserName</th>
                    <th>Phone</th>
                    <th>Website</th>
                </tr>
                </thead>
                <tbody>
                {
                    users.map((item)=><tr key={item.id}>
                        <td>{item.id}</td>
                        <td>{item.name}</td>
                        <td>{item.username}</td>
                        <td>{item.phone}</td>
                        <td>{item.website}</td>
                    </tr>)
                }
                </tbody>
            </table>
        </div>
    );
}

export default ThirdComponent;