import {Switch,Link,Route} from 'react-router-dom'
import Home from "./Components/Home";
import FirstComponent from "./Components/FirstComponent";
import SecondComponent from "./Components/SecondComponent";
import ThirdComponent from "./Components/ThirdComponent";
function App(){
    return(
        <div className={'container'}>
        <div className="row">
            <div className="col-md-12">
              <div className="navbar navbar-dark bg-dark">
                  <Link to={'/home'}><a href="" className={'navbar-brand'}>Home</a></Link>
              </div>
            </div>
        </div>

            <Switch>
                <Route path={'/home/third'} component={ThirdComponent}/>
                <Route path={'/home/second'} component={SecondComponent}/>
                <Route path={'/home/first'} component={FirstComponent}/>
                <Route path={'/home'} component={Home}/>
            </Switch>


        </div>
    )
}

export default App